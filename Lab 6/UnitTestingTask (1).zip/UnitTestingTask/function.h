#ifndef FUNCTION_H
#define FUNCTION_H
using namespace std;
int getFactorial(int val);
int subArraySum(int a[], int n, int start);
int check_anagram(char a[], char b[]);
int getStrongNess(string& input);
#endif
